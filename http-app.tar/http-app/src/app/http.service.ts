import { Injectable, EventEmitter } from '@angular/core';
import { Http, Headers, Response, RequestOptions } from "@angular/http";
import "rxjs/Rx";
import { Observable } from "rxjs/Rx";

import { Service } from "./services/service";


function construct_json_payload(input: any) {
	var payload = {};
	var service = {};
	var tunnelName = "tunnel-te" + input.tunnelId;
	
	service["name"] = tunnelName;
	service["serviceType"] = "tunnel";
	service["targetState"] = "Reserved";

	var requestData = {};
	requestData['tunnel-id'] = input.tunnelId;
	requestData['source'] = input.source;
	requestData['destination'] = input.destination;
	requestData["pcep"] = input.pcep;
	requestData['priority-setup'] = input.prioritySetup;
	requestData['priority-hold'] = input.priorityHold;
	requestData['hop-limit'] = input.hopLimit;

	if (input.metric != null || input.metric != undefined) {
		requestData['metric'] = input.metric;	
	}
	
	var bandwidthType = input.bandwidthType;
	if (bandwidthType != "auto") {
		requestData['bandwidth'] = 10;
	}

	
	var paths: any[] = [];
	var no_of_paths = input.paths.length;
	for (var i=0; i<no_of_paths; i++) {
		var path = {};
		path["path-option"] = input.paths[i].pathOption;
		path["name"] = tunnelName + "_" + input.paths[i].pathOption;
		path["type"] = "explicit";
		path["hops"] = [];
		paths.push(path);
	}

	requestData["paths"] = paths;
	service["requestData"] = requestData;
	payload['service'] = service;
	return payload;
}

@Injectable()
export class HttpService {
	constructor(private http: Http) { }

	createService(data: any){
		let payload = construct_json_payload(data);
		const body = JSON.stringify(payload);
		return this.http.post("http://10.61.35.79:8000/services", body)
			.map((response: Response) => response.json())
			.catch((error: any) => Observable.throw(error.json()));
	}

	deleteService(data: any){
		var delete_url = "http://10.61.35.79:8000/services/" + data;
		return this.http.delete(delete_url)
				.map((response: Response) => response.json())
				.catch((error: any) => Observable.throw(error.json()));
	}

	getServices() {
		return this.http.get("http://10.61.35.79:8000/services")
			.map((response: Response) => response.json())
			.catch((error: any) => Observable.throw(error.json()));
	}

	getService(id: string) {
		return this.http.get("http://10.61.35.79:8000/services/" + id)
			.map((response: Response) => response.json())
			.catch((error: any) => Observable.throw(error.json()));
	}
}