export handleSuccess(data: any){
    console.log(data.data.service);
    console.log(JSON.stringify(data));
  }

export handleError(error: any) {
    let messageCode = error.status.messages[0].msgCode;
    let messageText = error.status.messages[0].msgText;
    let messageTokens = error.status.messages[0].msgValues;
    console.log("Message Code: " + messageCode);
    console.log("Message Text: " + messageText);
    console.log("Message Tokens: " + messageTokens.toString());
 }