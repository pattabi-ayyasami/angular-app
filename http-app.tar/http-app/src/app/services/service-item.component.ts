import { Component, OnInit, Input } from '@angular/core';

import { Service } from "./service";
@Component({
  selector: 'dsm-service-item',
  templateUrl: './service-item.component.html',
  styles: []
})
export class ServiceItemComponent implements OnInit {

  @Input() service: Service;

  constructor() { }

  ngOnInit() {
  }

}
