/// <reference path="../EventSource.d.ts"/>

import { Component, OnInit } from '@angular/core';

import { Observable } from "rxjs/Rx";

import { HttpService } from "../http.service";
import { ServicesChangedEmitterService } from "../services-changed-emitter.service";

import { Service } from "./service";

@Component({
  selector: 'dsm-services',
  templateUrl: './services.component.html',
  styles: []
})
export class ServicesComponent implements OnInit {
	services: Service[] = [];
	private eventSource;

	constructor(private httpService: HttpService) { 
	}

	ngOnInit(){
		this.getServices();
		ServicesChangedEmitterService.getEmitter().subscribe(
			(data: any) => this.getServices()
		);

		
	}

  	getServices() {
  		this.httpService.getServices()
  		.subscribe(
			(data: any) => {
				var services: Service[]= [];
				console.log("Number of services: " + data.data.service.length)
				this.services = data.data.service;
			},
    		(error: any) => {
    			console.log(JSON.stringify(error));
              	alert(JSON.stringify(error));
    		}
    	);			
  	}

  	subscribe() {
  		console.log("Subscribing SSE events");
    	var url = 'http://10.61.35.79:8000/events/stream';
    	this.eventSource = new EventSource(url);
    	this.eventSource.addEventListener('message', this.onMessage, false);
    	this.eventSource.addEventListener('error', this.onError.bind(this), false);
  	}

  	unsubscribe() {
  		console.log("Unsubscribing SSE events");
    	this.eventSource.close();
  	}

  onMessage(msg) {
    console.log(msg);
    console.log("Emitting servicesChanged event");
    ServicesChangedEmitterService.getEmitter().emit();
  }

  onError(msg) {
    console.log(msg);
    console.log("Cancelling the event stream");
    this.eventSource.close();
  }
}
