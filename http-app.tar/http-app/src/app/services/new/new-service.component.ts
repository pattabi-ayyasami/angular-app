import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators, ValidatorFn, FormArray } from '@angular/forms';
import { Router } from "@angular/router";

import { Observable } from "rxjs/Rx";

import { HttpService } from "../../http.service";
import { ServicesChangedEmitterService } from "../../services-changed-emitter.service";

@Component({
  selector: 'dsm-new-service',
  templateUrl: './new-service.component.html',
  styles: []
})
export class NewServiceComponent implements OnInit {

	private heading = null;
	myForm: FormGroup = null;

	private serviceType = "tunnel";
	private tunnelType = "p2p";
	private signalingProtocol = "rsvp";
	private hopLimitDefaultValue: number = 10;
	private prioritySetupDefaultValue: number = 7;
	private priorityHoldDefaultValue: number = 7;
	 	
  	BANDWIDTH_TYPES = [
  		"auto",
  		"explicit"
  	];

  	setHeading() {
  		this.heading = "New MPLS TE Tunnel Service"
  	}

  	constructor(private formBuilder: FormBuilder,
          private router: Router,
  				private httpService: HttpService) { }

  	ngOnInit() {
	  	this.initForm();
	}

	initForm() {
  		this.setHeading();
  		this.myForm = this.formBuilder.group({
  			//'serviceType': [{value:this.serviceType, disabled: true}],
  			'tunnelType': [{value:this.tunnelType, disabled: true}],
  			'signalingProtocol': [{value:this.signalingProtocol, disabled: true}],
  			'tunnelId': ['', [Validators.required, Validators.pattern("[0-9]+")]],
  			'source': ['', Validators.required],
  			'destination': ['', Validators.required],
  			'pcep': [false],
  			'bandwidthType': ['auto', Validators.required],
  			'prioritySetup': [this.prioritySetupDefaultValue, [Validators.pattern("[0-9]+"), this.minValue(0), this.maxValue(7)]],
  			'priorityHold': [this.priorityHoldDefaultValue, [Validators.pattern("[0-9]+"), this.minValue(0), this.maxValue(7)]],
  			'hopLimit': [this.hopLimitDefaultValue, [Validators.pattern("[0-9]+"), this.minValue(1), this.maxValue(255)]],
  			'metric': [null, [Validators.pattern("[0-9]+"), this.minValue(0), this.maxValue(1000)]],
  			'paths': this.formBuilder.array([this.initPath()])
  		})
  	}

  	initPath() {
        return this.formBuilder.group({
            pathOption: [null, [Validators.required, Validators.pattern("[0-9]+")]]
        });
    }

    addPath() {
        const control = <FormArray>this.myForm.controls['paths'];
        control.push(this.initPath());
    }

    removePath(i: number) {
        const control = <FormArray>this.myForm.controls['paths'];
        control.removeAt(i);
    }

  	onSubmit() {
  		const formValue: any = this.myForm.value;
  		this.httpService.createService(formValue)
  			.subscribe(
  				(data: any) => {
  					console.log(JSON.stringify(data.data.service));
            console.log("Emitting servicesChanged event");
            ServicesChangedEmitterService.getEmitter().emit();
            this.navigateBack();
  				},
        		(error: any) => {
        			console.log(JSON.stringify(error));
              alert(JSON.stringify(error));
        		}
  		);
  	}

    navigateBack() {
  	   this.router.navigate(["../"]);
  	}

  	onCancel() {
  		if (this.myForm.dirty) {
  			if(confirm("There are unsaved changes. Proceed?")){
  				this.navigateBack();
  			}
  		} else {
  			this.navigateBack();
  		}
  	}

  	asyncNumberValidator(control: FormControl): Promise<any> | Observable<any> {
  		const promise = new Promise<any>(
  			(resolve, reject) => {
  				setTimeout(() => {
  					var pattern = /^\d+$/;
  					if (!pattern.test(control.value)) {
  						resolve({'invalid': true});
  					} else {
  						resolve(null)
  					}
  				}, 1500);
  			}
  		);
  		return promise;
  	}

  	minValue(min: Number): ValidatorFn {
  		return (control: FormControl): {[key: string]: any} => {
    		const input = control.value;
          	const isValid = input < min;
    		if(isValid) 
        		return { 'minValue': {min} }
    		else 
        		return null;
        }
  	}

  	maxValue(max: Number): ValidatorFn {
  		return (control: FormControl): {[key: string]: any} => {
    		const input = control.value;
          	const isValid = input > max;
    		if(isValid) 
        		return { 'maxValue': {max} }
    		else 
        		return null;
        }
  	}
}