import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from "@angular/router";

import { Subscription } from "rxjs/Rx";

import { TunnelServiceDetail } from './tunnel-service-detail';
import { HttpService } from '../../http.service';
import { ServicesChangedEmitterService } from "../../services-changed-emitter.service";

@Component({
  selector: 'dsm-service-detail',
  templateUrl: './service-detail.component.html',
  styles: []
})
export class ServiceDetailComponent implements OnInit {

  selectedService: TunnelServiceDetail = new TunnelServiceDetail();
  private subscription: Subscription;
  private serviceId: string;


  constructor(private route: ActivatedRoute, private router: Router,
  			  private httpService: HttpService) { }

  ngOnInit() {
  	  console.log("inside ngOnInit() of service detail component");
	  this.subscription = this.route.params.subscribe(
	  	(params: any) => {
	  		console.log(params);
	  		this.serviceId = params['id'];
	  		this.httpService.getService(this.serviceId)
  			.subscribe(
  				(data: any) => {
  					console.log("Service: " + JSON.stringify(data.data.service));
    				this.selectedService.name = data.data.service.name;
    				this.selectedService.serviceState = data.data.service.serviceState;
    				this.selectedService.id = data.data.service.id;
    				this.selectedService.serviceType = data.data.service.serviceType;
    				this.selectedService.createdBy = data.data.service.createdBy;
    				this.selectedService.createdOn = data.data.service.createdOn;
  				},
        		(error: any) => {
        			console.log(JSON.stringify(error));
              		alert(JSON.stringify(error));
        		}
  			);
	  	});
  }

  ngOnDestroy() {
  	this.subscription.unsubscribe();
  }

  	navigateBack() {
  		this.router.navigate(["../"]);
  	}

  deleteService() {
  	if (confirm("Do you want to delete the selected service?")) {
  		console.log(this.selectedService);
  		this.httpService.deleteService(this.serviceId)
  		.subscribe(
  				(data: any) => {
  					console.log("Emitting servicesChanged event");
  					ServicesChangedEmitterService.getEmitter().emit();
  				},
        		(error: any) => {
        			console.log(JSON.stringify(error));
              		alert(JSON.stringify(error));
        		}
  		);
  		this.navigateBack();
  	}
  }
}
