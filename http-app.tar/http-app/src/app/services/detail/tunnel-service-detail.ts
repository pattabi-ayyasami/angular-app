export class HopDetail {
	constructor(){}
}

export class PathDetail {
	public pathOption: number;
	public name: string;
	public type: string = "explicit";
	public hops: HopDetail[] = [];

	constructor() {
	}
}

export class TunnelServiceDetail {
	public id: string;
	public name:string;
	public serviceType: string ;
	public serviceState: string;
	public createdBy: string;
	public createdOn: string;
	
	public tunnelId: number;
	public source: string;
	public destination: string;
	public priorityHold: number;
	public prioritySetup: number;
	public hopLimit: number;
	public metric: number;
	public bandwidth: number;
	public bandwidthType: string;
	
	public paths: PathDetail[] = [];

    constructor() {
    }
}