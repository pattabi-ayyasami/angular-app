import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dsm-service-detail-default',
  template: `
    <h1>Service Details</h1>
    <h2>Select a service to view details</h2>
  `,
  styles: []
})
export class ServiceDetailDefaultComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
