export class Service {
	public id;
	public name:string;

    constructor() {
    }
}