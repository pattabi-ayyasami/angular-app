import { Routes } from "@angular/router"

import { NewServiceComponent } from "./new/new-service.component";
import { ServiceDetailComponent } from "./detail/service-detail.component";
import { ServiceDetailDefaultComponent } from "./detail/service-detail-default.component";

export const SERVICES_ROUTES: Routes = [
	{ path: '', component: ServiceDetailDefaultComponent },
	{ path: 'new', component: NewServiceComponent },
	{ path: ':id', component: ServiceDetailComponent }
];