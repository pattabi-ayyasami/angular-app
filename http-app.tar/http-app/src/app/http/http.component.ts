import { Component, OnInit } from '@angular/core';
import { Response } from "@angular/http";

import { HttpService } from "../http.service";

@Component({
  selector: 'app-http',
  templateUrl: './http.component.html',
  styles: []
})
export class HttpComponent implements OnInit {

  constructor(private httpService: HttpService) { }

  private serviceId = "l3vpn-1";

  ngOnInit() {
  	this.httpService.createService({})
  		.subscribe(
  			(data: any) => this.handleSuccess(data),
        (error: any) => {
          //this.handleError(error);
        }
  		);
  }

  handleSuccess(data: any){
    console.log(data.data.service);
    console.log(JSON.stringify(data));
  }

  handleError(error: any) {
    let messageCode = error.status.messages[0].msgCode;
    let messageText = error.status.messages[0].msgText;
    let messageTokens = error.status.messages[0].msgValues;
    console.log("Message Code: " + messageCode);
    console.log("Message Text: " + messageText);
    console.log("Message Tokens: " + messageTokens.toString());
  }

}
