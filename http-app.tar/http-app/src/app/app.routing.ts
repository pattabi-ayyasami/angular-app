import { RouterModule, Routes } from "@angular/router"
import { ModuleWithProviders } from "@angular/core"


import { ServicesComponent } from "./services/services.component";
import { NewServiceComponent } from "./services/new/new-service.component";
import { EventSourceComponent } from "./sse/event-source/event-source.component"

import { SERVICES_ROUTES } from "./services/services.routes";

const DSM_LITE_APP_ROUTES: Routes = [
	{ path: '', redirectTo: '/services', pathMatch: 'full' },
	{ path: 'services', component: ServicesComponent, children: SERVICES_ROUTES },
	{ path: 'subscribe', component: EventSourceComponent },
	{ path: '**', redirectTo: '/services', pathMatch: 'full' }
];

export const DsmLiteAppRoutingModule:ModuleWithProviders = RouterModule.forRoot(DSM_LITE_APP_ROUTES);