import { Injectable, EventEmitter } from '@angular/core';

@Injectable()
export class ServicesChangedEmitterService {
	private static _emitter: EventEmitter<any> = null;
  	
  	static getEmitter() {
  		if (!this._emitter) {
  			this._emitter = new EventEmitter();
  		}
  		return this._emitter;
  	}

}
