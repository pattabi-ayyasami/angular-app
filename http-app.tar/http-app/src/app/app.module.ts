import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { DsmLiteAppRoutingModule } from './app.routing';

import { AppComponent } from './app.component';
import { HttpComponent } from './http/http.component';

import { HttpService } from "./http.service";
import { NewServiceComponent } from './services/new/new-service.component';
import { HeaderComponent } from './header.component';
import { ServicesComponent } from './services/services.component';
import { ServiceItemComponent } from './services/service-item.component';
import { ServiceDetailComponent } from './services/detail/service-detail.component';
import { ServiceDetailDefaultComponent } from './services/detail/service-detail-default.component';
import { EventSourceComponent } from './sse/event-source/event-source.component';


@NgModule({
  declarations: [
    AppComponent,
    HttpComponent,
    NewServiceComponent,
    HeaderComponent,
    ServicesComponent,
    ServiceItemComponent,
    ServiceDetailComponent,
    ServiceDetailDefaultComponent,
    EventSourceComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,

    DsmLiteAppRoutingModule
  ],
  providers: [ HttpService ],
  bootstrap: [AppComponent]
})
export class AppModule { }
