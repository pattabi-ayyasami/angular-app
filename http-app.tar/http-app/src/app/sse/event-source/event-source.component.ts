/// <reference path="../../EventSource.d.ts"/>

import { Component, OnInit } from '@angular/core';
import { ServicesChangedEmitterService } from "../../services-changed-emitter.service";

@Component({
  selector: 'dsm-event-source',
  template: `
    <p>
      event-source Works!
    </p>
  `
})
export class EventSourceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    //console.log("Subscribing for the SSE events");
    //this.subscribe();
  }

  subscribe() {
    //console.log("Subscribing for the SSE events from 10.61.35.79");
    //var url = 'http://10.61.35.79:8000/events/stream';
    //let eventSource = new EventSource(url);
    //eventSource.addEventListener('message', this.callback);
  }

  callback(msg) {
    console.log(msg);
    console.log("Emitting servicesChanged event");
    ServicesChangedEmitterService.getEmitter().emit();
  }
}
